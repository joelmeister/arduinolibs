#ifndef _ULTRASONIC_H
#define _ULTRASONIC_H
#include <NewPing.h>
class Ultrasonic{
public:
	Ultrasonic();
	virtual ~Ultrasonic();
	unsigned int getDistance();
private:
	unsigned int distance;
	NewPing sonar;
};
#endif
